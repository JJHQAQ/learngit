可以直接运行Lab5.exe
