# ifndef JJH_main
# define JJH_main 666

void run(int,char**);

# endif