# ifndef JJH_call
# define JJH_call 233

void creat_file(char);
void get_datapath(void);
void find_path(void);

# endif