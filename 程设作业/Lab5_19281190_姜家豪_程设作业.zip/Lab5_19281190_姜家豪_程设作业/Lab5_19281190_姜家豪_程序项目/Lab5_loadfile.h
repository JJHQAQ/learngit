# ifndef JJH_loadfile 
# define JJH_loadfile 233
# include <cstdio>
void read_array(void);
void read_struct1(void);
void read_struct2(void);
void read_list(void);
int read(FILE*); 
# endif