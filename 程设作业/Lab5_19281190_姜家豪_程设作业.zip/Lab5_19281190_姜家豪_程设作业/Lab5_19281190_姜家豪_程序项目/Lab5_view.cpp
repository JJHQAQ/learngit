# include <cstdio>
# include "Lab5_data.h"

extern struct DATA data;

void out_array(void)
{
    printf("out mode 1 (array):\n");
    printf("recordnumber :   %d\n",data.cordnum);
    for (int i=0;i<data.cordnum;i++)
    {
        printf("%d %d %d\n",data.array1[i][0],data.array1[i][1],data.array1[i][2]);
        if (i%10==0){
            printf("continue?1(yes):0(no)\n");
            int num;
            scanf("%d",&num);
            if (num==0){
                break;
            }
        }  
    }
}

void out_struct1(void)
{
    printf("out mode 2 (struct):\n");
    printf("recordnumber :   %d\n",data.cordnum);
    for (int i=0;i<data.cordnum;i++)
    {
        printf("%d %d %d\n",data.st1[i].x,data.st1[i].y,data.st1[i].z);
        if (i%10==0){
            printf("continue?1(yes):0(no)\n");
            int num;
            scanf("%d",&num);
            if (num==0){
                break;
            }
        }  
    }
}

void out_struct2(void)
{
    printf("out mode 3 (point struct):\n");
    printf("recordnumber :   %d\n",data.cordnum);
    for (int i=0;i<data.cordnum;i++)
    {
        printf("%d %d %d\n",data.st2[i]->x,data.st2[i]->y,data.st2[i]->z);
        if (i%10==0){
            printf("continue?1(yes):0(no)\n");
            int num;
            scanf("%d",&num);
            if (num==0){
                break;
            }
        }  
    }
}

void out_list(void)
{
    printf("out mode 4 (list):\n");
    printf("recordnumber :   %d\n",data.head->val[0]);
    int i=0;
    for (struct Node2* P = data.head->next;P!=NULL;i++,P=P->next)
    {
        printf("%d %d %d\n",P->val[0],P->val[1],P->val[2]);
        if (i%10==0){
            printf("continue?1(yes):0(no)\n");
            int num;
            scanf("%d",&num);
            if (num==0){
                break;
            }
        }  
    }
}