# include <cstring>
# include "Lab5_data.h"
# include <stdlib.h>
# include <cstdio>
# include <iostream>
using namespace std;
extern struct Lab5init Lab;


void creat_file(char c)
{
    char s[1000]="Lab4.exe ";
    char t[100];
    t[0] = c;t[1] = '\0';
    strcat(s,t);
    strcat(s," ");
    if (Lab.mod[0]=='a')
    {   
        cout<<s<<endl;
        system(s);
    }else{
        printf("please input the savepath:\n");
        scanf("%s",t);
        strcat(s,t);
        strcat(s,"/");
        printf("please input the filename:\n");
        scanf("%s",t);
        strcat(s,t);
        strcat(s," ");
        printf("please input the recordnumber:\n");
        scanf("%s",t);
        strcat(s,t);
        cout<<s<<endl;
        system(s);
    }
}

void get_datapath()
{
    FILE* fp;
    if ((fp = fopen("filepath.txt","r"))==NULL)
    {
        printf("can't find datapath!\n");
        exit(0);
    }
    fscanf(fp,"%s",Lab.filename);
    int len = strlen(Lab.filename);
    Lab.form = (Lab.filename[len-2]=='a')?'d':'t';
    fclose(fp);
}

void find_path(void)
{
    printf("please input the loadpath\n");
    scanf("%s",Lab.filesavepath);
    printf("please input the load file name\n");
    scanf("%s",Lab.filename);
    int len = strlen(Lab.filesavepath);
    if (len>0) strcat(Lab.filesavepath,"/");
    strcat(Lab.filesavepath,Lab.filename);
    strcpy(Lab.filename,Lab.filesavepath);
    len = strlen(Lab.filename);
    Lab.form = (Lab.filename[len-2]=='a')?'d':'t';
}