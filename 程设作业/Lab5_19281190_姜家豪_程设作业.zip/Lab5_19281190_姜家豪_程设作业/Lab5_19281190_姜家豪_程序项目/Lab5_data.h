#ifndef JJH_data
#define JJH_data 666

struct Lab4init{
    char filename[1000];
    char filepath[1000];
    int maxvalue12;
    int minvalue12;
    int maxvalue3;
    int minvalue3;
    int maxrecord;
    int minrecord;
};

struct Lab5init{
    char filename[200];
    char filesavepath[200];
    char mod[200];
    char form;
    
};

struct Node1{
    int x,y,z;
};

struct Node2{
    int val[3];
    struct Node2* next;
};

struct DATA{
    int cordnum;
    int** array1;
    struct Node1* st1;
    struct Node1** st2;
    struct Node2*  head;
};

#endif
