# include "Lab5_data.h"
# include <cstdio>
# include <iostream>
# include <cstring>

extern struct DATA data;
extern struct Lab5init Lab; 


int read(FILE* fp)
{
    int temp;
    if (Lab.form=='t')    
        fscanf(fp,"%d",&temp);
    else
        fread(&temp,sizeof(int),1,fp);
    return temp;
}

void read_three(FILE* fp,int &x,int &y,int &z)
{
    if (Lab.form == 't')
    {
        fscanf(fp,"%d,%d,%d",&x,&y,&z);   
    }else{
        fread(&x,sizeof(int),1,fp);
        fread(&y,sizeof(int),1,fp);
        fread(&z,sizeof(int),1,fp);
    }
}


void read_array(void)
{
    FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }
    data.cordnum = read(fp);

    data.array1 = (int**)malloc(sizeof(int*)*data.cordnum);
    for (int i=0;i<data.cordnum;i++)
    data.array1[i] = (int*) malloc(sizeof(int)*3);

    for (int i=0;i<data.cordnum;i++)
    {
        read_three(fp,data.array1[i][0],data.array1[i][1],data.array1[i][2]);
    }    
    fclose(fp);
}

void read_struct1(void)
{
    FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }
    data.cordnum = read(fp);

    data.st1 = (struct Node1*)malloc(sizeof(struct Node1)*data.cordnum);
    
    for (int i=0;i<data.cordnum;i++)
    {
        read_three(fp,data.st1[i].x,data.st1[i].y,data.st1[i].z);
    }
    
    fclose(fp);
}

void read_struct2(void)
{
     FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }
    data.cordnum = read(fp);

    data.st2 = (struct Node1**)malloc(sizeof(struct Node1*)*data.cordnum);
    for (int i=0;i<data.cordnum;i++)
    data.st2[i] = (struct Node1*)malloc(sizeof(struct Node1));

    for (int i=0;i<data.cordnum;i++)
    {
        read_three(fp,data.st2[i]->x,data.st2[i]->y,data.st2[i]->z);
    }

    fclose(fp);
}

void read_list(void)
{
    FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }

    data.head = (struct Node2*)malloc(sizeof(struct Node2));
    data.head->val[0] = read(fp);
    data.head->next = NULL;

    struct Node2* Nowpoint=data.head;

    for (int i=0;i<data.head->val[0];i++)
    {
        struct Node2* temp;
        temp = (struct Node2*)malloc(sizeof(struct Node2));
        read_three(fp,temp->val[0],temp->val[1],temp->val[2]);
        temp->next = NULL;
        Nowpoint->next = temp;
        Nowpoint = temp;    
    }

    fclose(fp);
}