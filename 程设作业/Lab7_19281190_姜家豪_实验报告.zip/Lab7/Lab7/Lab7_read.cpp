# include "Lab7_data.h"
# include <cstring>
# include <cstdio>
# include <cstdlib>
extern  DATA data;

void creat_data(void)//调用实验四生成数据
{
    system("Lab4.exe t");
    FILE* fp;
    if ((fp=fopen("filepath.txt","r"))==NULL)
    {
        printf("Creat data fail!\n");
        exit(0);
    }
    fscanf(fp,"%s",data.filepath);
    fclose(fp);
}

void read_txt(char* s)//读取数据
{
    FILE* fp;
    if ((fp=fopen(s,"r"))==NULL)
    {
        printf("Can't find file!\n");
        exit(0);
    }
    fscanf(fp,"%d",&data.num);
    data.ord = (PUSERCALL)malloc(sizeof(USERCALL)*data.num);
    for (int i=0;i<data.num;i++)
    {
    fscanf(fp,"%d,%d,%d",&data.ord[i].user_floor,&data.ord[i].user_target,&data.ord[i].call_time);
    data.ord[i].id = i;
    data.ord[i].call_type = (data.ord[i].user_target>data.ord[i].user_floor)?'U':'D';
    }
    fclose(fp);
}

int cmp(const void* a,const void* b)
{
    return ((PUSERCALL)a)->call_time - ((PUSERCALL)b)->call_time;
}

void read_file(int argc,char* argv[])//读取文件
{
    if (argc>1)//如果指定了文件
    {
        strcpy(data.filepath,argv[1]);
    }
    else
    {
        creat_data();//调用实验四生成数据
    }
    read_txt(data.filepath);//读取数据

    qsort(data.ord,data.num,sizeof(USERCALL),cmp);//排序

    // FILE* fp;
    // if ((fp=fopen("JJH.txt","w"))==NULL)
    // {
    //     printf("creat_fail!\n");
    // }
    // fprintf(fp,"%d\n",data.num);
    // for (int i=0;i<data.num;i++)
    // {
    //     fprintf(fp,"%d,%d,%d\n",data.ord[i].user_floor,data.ord[i].user_target,data.ord[i].call_time);
    // }

}