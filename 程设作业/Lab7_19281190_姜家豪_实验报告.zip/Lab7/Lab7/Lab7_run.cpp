#include "Lab7_data.h"
# include <cstdio>
# include <cstdlib>
extern DATA data;
extern ELEVATORSTATE  elevator;
extern RESPONSELISTHEADNODE response;
void init()//初始化
{
    data.Time = 0;
    data.now = 0;
    response.list_num=0;
    response.head = (RESPONSELISTNODE *)malloc(sizeof(RESPONSELISTNODE));
    response.head->next_node = NULL;
    response.tail = NULL;
    elevator.current_floor = 1;
    elevator.run_state = 'S';
    elevator.serve_list = (SERVELISTNODE *)malloc(sizeof(SERVELISTNODE));
    elevator.serve_list->next_node = NULL;
}

void add_response()//添加到待响应队列
{
    while(data.now<data.num  &&  data.Time>=data.ord[data.now].call_time)
    {
        response.list_num++;
        RESPONSELISTNODE* tmp = (RESPONSELISTNODE *)malloc(sizeof(RESPONSELISTNODE));
        tmp->next_node = NULL;
        tmp->user_call = (data.ord+data.now);
        if (response.head->next_node==NULL) response.head->next_node = tmp;
        if (response.tail==NULL) response.tail = tmp;
        else{
            response.tail->next_node = tmp;
            response.tail = response.tail->next_node;
            response.tail->next_node = NULL;
        }
        data.now++;
    }
}

void run_state_S()//处理S状态
{
    if (elevator.serve_list->next_node==NULL)//处理当前服务队列全空状态
        {
            if (response.head->next_node!=NULL)//如果待响应队列非空
            {
                //添加第一个待响应命令加入当前服务队列
                SERVELISTNODE * tmp = (SERVELISTNODE *)malloc(sizeof(SERVELISTNODE));
                tmp->next_node = NULL;
                tmp->user_call = response.head->next_node->user_call;
                tmp->serve_state = (elevator.current_floor == tmp->user_call->user_floor)?'E':'P';
                elevator.serve_list->next_node = tmp;
                

                //根据加入的命令确定电梯的运行方向
                if (tmp->serve_state == 'E')
                {
                printf("people: %d   get on!\n",tmp->user_call->id);
                elevator.run_state = tmp->user_call->call_type;
                }
                else
                {
                    if (tmp->user_call->user_floor > elevator.current_floor) elevator.run_state = 'U';
                    else elevator.run_state = 'D';
                }

                //释放待响应命令中被加入的节点，防止内存泄露
                RESPONSELISTNODE * tmp2 = response.head->next_node->next_node;
                free(response.head->next_node);
                response.head->next_node = tmp2;
                
                if (response.head->next_node==NULL) response.tail = NULL;
                response.list_num--;
            }
        }
        else//如果当前服务队列非空 则根据第一个节点确定电梯的运行方向
        {
            if (elevator.serve_list->next_node->serve_state=='P')
            {
                if (elevator.serve_list->next_node->user_call->user_floor  > elevator.current_floor) elevator.run_state = 'U';
                else elevator.run_state = 'D';
            }
            else{
                if (elevator.serve_list->next_node->user_call->user_target > elevator.current_floor) elevator.run_state = 'U';
                else elevator.run_state = 'D';

            }
        }


    RESPONSELISTNODE * tmp2 = response.head;
    RESPONSELISTNODE * tmp3;


    if (elevator.run_state=='U')//确定为U方向后，加入其他可以同时响应的节点。
    {
        while(tmp2->next_node!=NULL)
        {
            if (tmp2->next_node->user_call->user_floor >= elevator.current_floor && tmp2->next_node->user_call->call_type == 'U')
            {
            tmp3 = tmp2->next_node;
            tmp2->next_node=tmp2->next_node->next_node;

            if (tmp2->next_node == NULL) response.tail = tmp2;

            SERVELISTNODE * tmp4 = ( SERVELISTNODE *)malloc(sizeof(SERVELISTNODE));
            tmp4->user_call = tmp3->user_call;
            free(tmp3);

            tmp4->next_node = elevator.serve_list->next_node;
            elevator.serve_list->next_node = tmp4;

            tmp4->serve_state=(tmp4->user_call->user_floor==elevator.current_floor)?'E':'P';
            
            if (tmp4->serve_state=='E');
            printf("people: %d   get on!\n",tmp4->user_call->id);
            
            response.list_num--;
            }else
            {
                tmp2 = tmp2->next_node;
            }
        }
    }
    
    
    tmp2 = response.head;


    if (elevator.run_state=='D')//确定为D方向后，加入其他可以同时响应的节点。
    {
    while(tmp2->next_node!=NULL)
    {
        if (tmp2->next_node->user_call->user_floor <= elevator.current_floor && tmp2->next_node->user_call->call_type == 'D')
        {
        tmp3 = tmp2->next_node;
        tmp2->next_node=tmp2->next_node->next_node;

        if (tmp2->next_node == NULL) response.tail = tmp2;


        SERVELISTNODE * tmp4 = ( SERVELISTNODE *)malloc(sizeof(SERVELISTNODE));
        tmp4->user_call = tmp3->user_call;
        free(tmp3);

        tmp4->next_node = elevator.serve_list->next_node;
        elevator.serve_list->next_node = tmp4;


        tmp4->serve_state=(tmp4->user_call->user_floor==elevator.current_floor)?'E':'P';
        
        if (tmp4->serve_state=='E');
        printf("people: %d   get on!\n",tmp4->user_call->id);
        
        response.list_num--;
        }else
        {
            tmp2 = tmp2->next_node;
        }
        
    } 
    }


}

void run_state_U()//处理当前状态为U的情况
{

    //加入能同时响应的节点。
    RESPONSELISTNODE * tmp2 = response.head;
    RESPONSELISTNODE * tmp3;
    while(tmp2->next_node!=NULL)
        {
            // printf("Uwhile1\n");
        if (tmp2->next_node->user_call->user_floor > elevator.current_floor && tmp2->next_node->user_call->call_type == 'U')
            {

                tmp3 = tmp2->next_node;
                tmp2->next_node=tmp2->next_node->next_node;

                if (tmp2->next_node == NULL) response.tail = tmp2;


                SERVELISTNODE * tmp4 = ( SERVELISTNODE *)malloc(sizeof(SERVELISTNODE));
                tmp4->user_call = tmp3->user_call;
                free(tmp3);
                tmp4->next_node = elevator.serve_list->next_node;
                elevator.serve_list->next_node = tmp4;


                tmp4->serve_state = 'P';
                response.list_num--;
            }else{
                tmp2 = tmp2->next_node;
            }

        }
    



    elevator.current_floor++;//上升一楼


    //处理当前楼层能处理的节点
    SERVELISTNODE*  tmp5 = elevator.serve_list;
    while(tmp5->next_node!=NULL)
    {
        if (tmp5->next_node->serve_state=='P')//处理服务前状态
        {
            if (tmp5->next_node->user_call->user_floor == elevator.current_floor) {
                tmp5->next_node->serve_state = 'E';
                elevator.run_state = 'S';
                
                printf("people: %d   get on!\n",tmp5->next_node->user_call->id);
            }
            tmp5 = tmp5->next_node;
            continue;
        }

        if (tmp5->next_node->serve_state=='E')//处理服务中状态
        {
            if (tmp5->next_node->user_call->user_target == elevator.current_floor)
            {
                elevator.run_state = 'S';
                SERVELISTNODE* tmp6;
                tmp6 = tmp5->next_node;
                tmp5->next_node = tmp5->next_node->next_node;

                printf("people: %d   get off!\n",tmp6->user_call->id);

                free(tmp6);
            }else{
                tmp5 = tmp5->next_node;
            }
        }
    }
   


}

void run_state_D()//处理当前状态为D的状态
{
    //加入可以同时响应的节点
    RESPONSELISTNODE * tmp2 = response.head;
    RESPONSELISTNODE * tmp3;
    while(tmp2->next_node!=NULL)
        {
        if (tmp2->next_node->user_call->user_floor < elevator.current_floor && tmp2->next_node->user_call->call_type == 'D')
            {

                tmp3 = tmp2->next_node;
                tmp2->next_node=tmp2->next_node->next_node;

                if (tmp2->next_node == NULL) response.tail = tmp2;


                SERVELISTNODE * tmp4 = ( SERVELISTNODE *)malloc(sizeof(SERVELISTNODE));
                tmp4->user_call = tmp3->user_call;
                free(tmp3);
                tmp4->next_node = elevator.serve_list->next_node;
                elevator.serve_list->next_node = tmp4;

                tmp4->serve_state = 'P';
                response.list_num--;
            }else{
                tmp2 = tmp2->next_node;
            }

        }
    
    
    elevator.current_floor--;//下降一楼
    
    //处理能处理的当前服务队列中的节点
    SERVELISTNODE*  tmp5 = elevator.serve_list;
    while(tmp5->next_node!=NULL)
    {
        if (tmp5->next_node->serve_state=='P')
        {
            if (tmp5->next_node->user_call->user_floor == elevator.current_floor) {
                tmp5->next_node->serve_state = 'E';
                elevator.run_state = 'S';

                printf("people: %d   get on!\n",tmp5->next_node->user_call->id);
            }
            tmp5 = tmp5->next_node;
            continue;
        }

        if (tmp5->next_node->serve_state=='E')
        {
            if (tmp5->next_node->user_call->user_target == elevator.current_floor)
            {
                elevator.run_state = 'S';
                SERVELISTNODE* tmp6;
                tmp6 = tmp5->next_node;
                tmp5->next_node = tmp5->next_node->next_node;

                printf("people: %d   get off!\n",tmp6->user_call->id);
                
                free(tmp6);
            }else{
                tmp5 = tmp5->next_node;
            }
        }
    }
}

void add_ord()//处理这一秒的电梯状态
{
    if (elevator.run_state =='S')
    {
        run_state_S();
        return;
    }


    if (elevator.run_state == 'U')
    {
        run_state_U();
        return;
    }


    if (elevator.run_state == 'D')
    {
        run_state_D();
        return ;
    }


}

void doyouwork()//模拟电梯状态
{
    add_response();//加入该时刻新加入的命令到待响应队列
    add_ord();//添加能同时响应的指令，并处理当前时刻的指令。
}