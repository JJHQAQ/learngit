#ifndef JJH_run 
#define JJH_run 233
void init();
void doyouwork();
#endif