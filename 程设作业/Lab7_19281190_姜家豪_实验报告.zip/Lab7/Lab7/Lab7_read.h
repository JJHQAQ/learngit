#ifndef JJH_read
#define JJH_read   233

void read_file(int,char**);
void read_txt(char*);
void creat_data();
#endif