# include <cstdio>
# include <iostream>
# include <windows.h>
# include "Lab7_read.h"
# include "Lab7_data.h"
# include "Lab7_run.h"

using namespace std;

DATA data;
ELEVATORSTATE  elevator;
RESPONSELISTHEADNODE response;
int main(int argc,char* argv[])
{   
    read_file(argc, argv);//读取文件
    init();//初始化
    while(true)
    {
        //输出信息
        printf("current time:  %d\n",data.Time);
        printf("current run_state: %c\n",elevator.run_state);
        
        doyouwork();//模拟下一秒的状态
        
        //输出信息
        printf("current floor: %d\n",elevator.current_floor);
        printf("-----------------------------------\n");


        data.Time++;
        Sleep(1000);


        //结束条件
        if (data.now==data.num && response.list_num==0 && elevator.serve_list->next_node==NULL) break;
    }
    printf("end run!\n");
    return 0;
}