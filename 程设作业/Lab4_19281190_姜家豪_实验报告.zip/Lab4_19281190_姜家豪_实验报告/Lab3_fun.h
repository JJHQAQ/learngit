#ifndef JJH_Lab_fun

#define JJH_Lab_fun
void init(void);
//初始化主要结构体中各个变量

int judge_num(char*);
//判断输入的数字字符串是否合法,
//如果输入'r'则返回-1，表示随机数；
//如果非法则返回-2，否则返回字符转换出的非负整数。

int judge_name(char*);
//判断输入路径字符串是否合法，输入参数是字符串，返回值为整数
//当路径非法时返回-2，否则返回最后一个'\'或者'/'的位置，如果没有则返回-1

void get_name(char*,int);
//将路径字符串拆分为文件名和路径并存入主数据结构体。第一个参数为路径字符串，第二个参数为最后一个'\'的位置。

int get_rand(int,int);
//参数为区间的左右端点，返回闭区间中的任意一个整数

void search_num(void);
//当输入没有数字时启动，不断向用户询问记录条数。

void search_name(void);
//当输入没有路径启动，不断向用户询问保存路径。

void creat_data(void);
//在指定路径文件中写入数据。

void creat_dat(void);
/*
制作txt文件函数
函数作用，将数据输出到指定txt文件中。
*/


void creat_txt(void);
/*
制作二进制文件函数
函数作用，将数据输出到指定二进制文件中。
*/


void search_form(void);
/*
提示输入正确指示符的函数
*/
#endif