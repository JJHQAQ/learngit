/*
程序作用：制造随机三元组
相关文件：
Lab3_run.h
Lab3_run.cpp
Lab3_fun.h
Lab3_fun.cpp
Lab3_data.h
输入参数：
至多两个，数据条数与储存路径
主要作用函数run的注释所在：Lab3_run.cpp
run函数各个子函数的作用注释：Lab3_fun.h
具体变量作用注释所在：Lab3_data.h
完成者：19281190 计算机1907 姜家豪
*/

# include <cstdio>
# include <iostream>
# include "Lab3_run.h"
# include "Lab3_fun.h"
# include "Lab3_data.h"

using namespace std;

CONF Lab;
DATAITEM D_three;
int main(int argc,char* argv[])
{
    run(argc,argv);
    return 0;
}