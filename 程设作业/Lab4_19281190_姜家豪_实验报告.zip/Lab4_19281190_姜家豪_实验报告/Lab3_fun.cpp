# include <stdio.h>
# include <cstdio>
# include <cstring>
# include <cstdlib>
# include <time.h>
# include <io.h>
# include <direct.h>
# include <iostream>
# include <malloc.h>
# include "Lab3_fun.h"
# include "Lab3_data.h"
using namespace std;
extern struct configinfo Lab;
extern PDATAITEM  D_three;

/*
初始化函数
函数作用：从conf.ini文件读取初始化信息并初始化
*/
void init(void)
{
    srand(time(NULL));
    FILE* fp;
    if ((fp=fopen("conf.ini","r"))==NULL)
    {
        cout<<"open init file fali!"<<endl;
        exit(0);
    }
    Lab.form = 'b';
    fscanf(fp,"%s",Lab.filesavepath);
    fscanf(fp,"%s",Lab.filename);
    fscanf(fp,"%d",&Lab.maxvalue1);
    fscanf(fp,"%d",&Lab.minvalue1);
    fscanf(fp,"%d",&Lab.maxvalue2);
    fscanf(fp,"%d",&Lab.minvalue2);
    fscanf(fp,"%d",&Lab.recordcount);
    fscanf(fp,"%d",&Lab.recordcount2);
    Lab.number = get_rand(Lab.recordcount2,Lab.recordcount);
    return ;
}


//判断输入的数字字符串是否合法,
//如果输入'r'则返回-1，表示随机数；
//如果非法则返回-2，否则返回字符转换出的非负整数。
int judge_num(char* s)
{
    int len = strlen(s);
    if (len<0) return -2;
    if (len==1&&s[0]=='r') return -1;
    for (int i=0;i<len;i++)
    {
        if (s[i]<'0'||s[i]>'9') return -2;
    }
    int num = 0;
    for (int i=0;i<len;i++) 
    {
        num=num*10+s[i]-'0';
    }
    return num;
}


//判断输入路径字符串是否合法，输入参数是字符串，返回值为整数
//当路径非法时返回-2，否则返回最后一个'\'或者'/'的位置，如果没有则返回-1

int judge_name(char* s)
{
    int len = strlen(s);
    if (len<=4) return -2;
    
    for (int i=0,num=0,fl=0;i<len;i++)
    {
        if (s[i]=='*'||s[i]=='?'||s[i]=='<'||s[i]=='>'||s[i]=='|') return -2;
        if (s[i]==':')
        {
            if (fl) return -2;
            i++;
            if (s[i]=='\\') fl=1;
            else return -2;
            if (num==0) return -2;
            num=0;
        }
        else
        if (s[i]=='/'){
            if (num==0) return -2;
            num=0; 
        }
        else
        if (s[i]=='\\'){
            i++;
            if (s[i]=='\\') {
                if (num==0) return -2;
                num=0;
            }else return -2;
        }
        num++;
    }
 
 
    char a[]= ".txt";
    bool flag = true;
    for (int i=0;i<=3;i++) {
        if (s[len-4+i]!=a[i]) flag = false;
    }

    if (!flag){
        char b[] = ".dat";
        flag =true;
        for (int i=0;i<=3;i++) 
        if (s[len-4+i]!=b[i]) flag = false;
    }

    if (!flag) return -2;
    for (int i=len-1;i>=0;i--)
    {
        if (s[i]=='\\'||s[i]=='/'||s[i]==':') {
            if (len-i>5) return i;
        }
    }
    return -1;
}


//将路径字符串拆分为文件名和路径并存入主数据结构体。第一个参数为路径字符串，第二个参数为最后一个'\'的位置。
void get_name(char* s,int flag)
{
    int len = strlen(s);
    int i;
    for (i=0;s[flag+1+i]!='\0';i++)
    Lab.filename[i] = s[flag+1+i];
    Lab.filename[i] = '\0';
    for (i=0;i<flag;i++)
    Lab.filesavepath[i] = s[i];
    Lab.filesavepath[i] = '\0';
}


//参数为区间的左右端点，返回闭区间中的任意一个整数
int get_rand(int l,int r)//取区间中的随机一个整数。
{   
    return l+rand()%(r-l+1);
}


//当输入没有数字时启动，不断向用户询问记录条数。
void search_num(void)
{
    char s[100]="\0";
    int flag = -2;
    while(flag==-2)
    {
        printf("please input the record number(intput 'r' for a random number)：\n");
        scanf("%s",s);
        flag = judge_num(s);
    }
    if (flag==-1) 
    {
        Lab.number = get_rand(Lab.recordcount2,Lab.recordcount);
    }
    else
    {
        Lab.number = flag;
    }
    return ;
}


//当输入没有路径启动，不断向用户询问保存路径。
void search_name(void)
{
    char s[100] = "\0";
    int flag = -2;
    while(flag==-2)
    {
        printf("Please intput the correct savepath:\n");
        scanf("%s",s);
        flag = judge_name(s);
        cout<<flag<<endl;
    }
    get_name(s,flag);
}


//在指定路径文件中写入数据。
void creat_data(void)
{
    clock_t start = clock();
    if (strlen(Lab.filesavepath)>0)
    if (access(Lab.filesavepath,0)==-1)
    {
        if (mkdir(Lab.filesavepath)==-1){
            printf("make dir fail！\n");
            return;
        }
    }

    D_three = (PDATAITEM)malloc(Lab.number*sizeof(DATAITEM));
    if (D_three==NULL) {
        printf("malloc file!\n");
        exit(0);
    }

    for (int i=0;i<Lab.number;i++)
    {
        D_three[i].Item1  = get_rand(Lab.minvalue1,Lab.maxvalue1);
        D_three[i].Item2  = get_rand(Lab.minvalue1,Lab.maxvalue1);
        while(D_three[i].Item2==D_three[i].Item1)
        {
            D_three[i].Item2  = get_rand(Lab.minvalue1,Lab.maxvalue1);
        }
        D_three[i].Item3  = get_rand(Lab.minvalue2,Lab.maxvalue2);
    }
    clock_t finish = clock();
    printf("creat data success in :%lf s\n",(double)(finish-start)/(double)CLOCKS_PER_SEC);
    return ;
}

/*
制作txt文件函数
函数作用，将数据输出到指定txt文件中。
*/

void creat_txt(void)
{
    clock_t start = clock();

    char s[100];
    int len = strlen(Lab.filesavepath);
    int i = 0;
    for (;i<len;i++) s[i] = Lab.filesavepath[i];
    if (i>0) s[i++]='\\';
    len = strlen(Lab.filename);
    for (int j=0;j<len;j++) s[i+j] = Lab.filename[j];
    s[i+len] = '\0';
    len+=i;
    FILE* fp;
    if ((fp=fopen(s,"w+"))==NULL) {
        cout<<"open file fail!\n"<<endl;
        exit(0);
    }
    fprintf(fp,"%d\n",Lab.number);
    for (int i=0;i<Lab.number;i++)
    {
        fprintf(fp,"%d %d %d\n",D_three[i].Item1,D_three[i].Item2,D_three[i].Item3);
    }
    fclose(fp);

    clock_t finish = clock();
    printf("make txt success in :%lf s\n",(double)(finish-start)/(double)CLOCKS_PER_SEC);
}

/*
制作二进制文件函数
函数作用，将数据输出到指定二进制文件中。
*/
void creat_dat(void)
{
    clock_t start = clock();

    char s[100];
    int len = strlen(Lab.filesavepath);
    int i = 0;
    for (;i<len;i++) s[i] = Lab.filesavepath[i];
    if (i>0) s[i++]='\\';
    len = strlen(Lab.filename);
    for (int j=0;j<len;j++) s[i+j] = Lab.filename[j];
    s[i+len] = '\0';
    len+=i;
    char sts[] = "dat";
    for (int i=len-3;i<len;i++)s[i] = sts[i-len+3];//creat filename

    FILE* fp;
    if ((fp=fopen(s,"wb+"))==NULL) {
        cout<<"creat file fail!\n"<<endl;
        exit(0);
    }//open the file


    fwrite(&Lab.number,4,1,fp);
    fwrite(D_three,4,3*Lab.number,fp);//output the dat file
    
    fclose(fp);

    clock_t finish = clock();
    printf("make dat success in :%lf s\n",(double)(finish-start)/(double)CLOCKS_PER_SEC);
}

/*
提示输入正确指示符的函数
*/
void search_form()
{   
    char s[100];
    do {
        printf("please input the correct form('t' or 'd'):\n");
        scanf("%s",s);
    }while(strlen(s)>1||!(s[0]=='t'||s[0]=='d'));
    Lab.form = s[0];
}