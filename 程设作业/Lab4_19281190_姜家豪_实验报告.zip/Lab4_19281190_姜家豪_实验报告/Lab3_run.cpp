# include <stdio.h>
# include <iostream>
# include <malloc.h>
# include "Lab3_run.h"
# include "Lab3_fun.h"
# include "Lab3_data.h"
# include <cstring>

using namespace std;
extern struct configinfo Lab;
extern PDATAITEM D_three;

void run(int argc,char* argv[])
{
    init();//初始化

    if (argc>4)//命令过多的情况
    {
        printf("输入命令过多！\n");
        return ;
    }

    if (argc>=2)//输入了一条数据的情况
    {
        int flag = 0;
        if ((flag=judge_num(argv[1]))>=0)//判断该数据是否为数字。
        {
            Lab.number = flag;
        }else
        {
            search_num();
        }
    }

    if (argc>=3)//输入了两个数据的情况
    {
        int flag = 0;
        if ((flag=judge_name(argv[2]))!=-2)//继续判断第二个数据是否为合法路径
        {
            get_name(argv[2],flag);
        }else{
            search_name();   
        }
    }

    if (argc>=4)//输入了三个数据的情况
    {
        if (strlen(argv[3])==1&&(argv[3][0]=='t'||argv[3][0]=='d'))//判断第三个数据是否是需要的文件格式指示符号
        {
            Lab.form = argv[3][0];
        }
        else
        {
            search_form();
        }
    }

    
    creat_data();//造数据


    switch (Lab.form)
    {
    case 'b':
    case 't':
    creat_txt();
    break;
    }
    switch (Lab.form)
    {
    case 'b':
    case 'd':
    creat_dat();
    break;
    }

    
    free(D_three);
    cout<<"end run"<<endl;
    return;
}