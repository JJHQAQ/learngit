#ifndef JJH_Lab_run
#define JJH_Lab_run
void run(int argc,char* argv[]);//程序主体
# endif