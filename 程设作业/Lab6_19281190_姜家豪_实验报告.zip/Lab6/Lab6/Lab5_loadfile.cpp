# include "Lab5_data.h"
# include <cstdio>
# include <iostream>
# include <cstring>
# include <stdlib.h>
# include "Lab5_view.h"

extern struct DATA data;
extern struct Lab5init Lab; 


int read(FILE* fp)
{
    int temp;
    if (Lab.form=='t')    
        fscanf(fp,"%d",&temp);
    else
        fread(&temp,sizeof(int),1,fp);
    return temp;
}

void read_three(FILE* fp,int &x,int &y,int &z)
{
    if (Lab.form == 't')
    {
        fscanf(fp,"%d,%d,%d",&x,&y,&z);   
    }else{
        fread(&x,sizeof(int),1,fp);
        fread(&y,sizeof(int),1,fp);
        fread(&z,sizeof(int),1,fp);
    }
}

int cmparray(const void * a,const void * b)
{
    return (*(int**)a)[2]-(*(int**)b)[2];
}


void read_array(void)
{
    FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }
    data.cordnum = read(fp);

    data.array1 = (int**)malloc(sizeof(int*)*data.cordnum);
    for (int i=0;i<data.cordnum;i++)
    data.array1[i] = (int*) malloc(sizeof(int)*3);

    for (int i=0;i<data.cordnum;i++)
    {
        read_three(fp,data.array1[i][0],data.array1[i][1],data.array1[i][2]);
    }  
    printf("sort or not?(1:yes  0:no)\n");
    int tmp;
    scanf("%d",&tmp);
    if (tmp!=0)
    {  
    qsort(data.array1,data.cordnum,sizeof(data.array1[0]),cmparray);
    printf("sort complete!\n");
    }
    fclose(fp);
}

int cmpstruct1(const void* a,const void* b)
{
    return (*(struct Node1*)a).z-(*(struct Node1*)b).z;
}

void read_struct1(void)
{
    FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }
    data.cordnum = read(fp);

    data.st1 = (struct Node1*)malloc(sizeof(struct Node1)*data.cordnum);
    
    for (int i=0;i<data.cordnum;i++)
    {
        read_three(fp,data.st1[i].x,data.st1[i].y,data.st1[i].z);
    }
      printf("sort or not?(1:yes  0:no)\n");
    int tmp;
    scanf("%d",&tmp);
    if (tmp!=0)
    {  
    qsort(data.st1,data.cordnum,sizeof(data.st1[0]),cmpstruct1);
    printf("sort complete!\n");
    }
    fclose(fp);
}

int cmpstruct2(const void * a,const void * b)
{
    return (*(struct Node1**)a)->z - (*(struct Node1**)b)->z;
}

void read_struct2(void)
{
     FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }
    data.cordnum = read(fp);

    data.st2 = (struct Node1**)malloc(sizeof(struct Node1*)*data.cordnum);
    for (int i=0;i<data.cordnum;i++)
    data.st2[i] = (struct Node1*)malloc(sizeof(struct Node1));

    for (int i=0;i<data.cordnum;i++)
    {
        read_three(fp,data.st2[i]->x,data.st2[i]->y,data.st2[i]->z);
    }
    printf("sort or not?(1:yes  0:no)\n");
    int tmp;
    scanf("%d",&tmp);
    if (tmp!=0)
    { 
    qsort(data.st2,data.cordnum,sizeof(data.st2[0]),cmpstruct2);
     printf("sort complete!\n");
    }
    fclose(fp);
}

void sortlist(struct Node2* &h)
{
    if (h->next == NULL) return;
    struct Node2* tmp = h->next;
    int mid = tmp->val[2];
    
    struct Node2* left,*right,*midnode;
    left = (struct Node2*)malloc(sizeof(struct Node2));
    left->next = NULL;
    midnode=(struct Node2*)malloc(sizeof(struct Node2));
    midnode->next = NULL;
    right = (struct Node2*)malloc(sizeof(struct Node2));
    right->next = NULL;

    struct Node2* lastleft,*lastright,*lastmid;
    lastleft = left;lastright = right;lastmid = midnode; 

    while(tmp!=NULL)//分链
    {
        if (tmp->val[2]==mid)
        {
            lastmid->next = tmp;
            lastmid = lastmid->next;
            tmp = tmp->next;
            lastmid->next = NULL;
        }else if (tmp->val[2]>mid)
        {
            lastright->next = tmp;
            lastright = lastright->next;
            tmp = tmp->next;
            lastright->next = NULL;
        }else{
            lastleft->next = tmp;
            lastleft = lastleft->next;
            tmp = tmp->next;
            lastleft->next = NULL;
        }
    }

    sortlist(left);//递归排序子链表
    sortlist(right);

    //以下属于防止内存泄露与连接子链表
    free(h);
    if (left->next!=NULL)
    {
        h = left;
        tmp = h->next;
        while(tmp->next!=NULL) tmp = tmp->next;
        tmp->next = midnode->next;
        free(midnode);
    }else
    {
        free(left);
        h = midnode;
    }
        lastmid->next = right->next;
    free(right);
    return ;
}


void read_list(void)
{
    FILE* fp;
    if ( (fp=fopen(Lab.filename,"r")) == NULL)
    {
        printf("Con't find data!\n");
        exit(0);
    }

    data.head = (struct Node2*)malloc(sizeof(struct Node2));
    data.cordnum = read(fp);
    data.head->next = NULL;

    struct Node2* Nowpoint=data.head;

    for (int i=0;i<data.cordnum;i++)
    {
        struct Node2* temp;
        temp = (struct Node2*)malloc(sizeof(struct Node2));
        read_three(fp,temp->val[0],temp->val[1],temp->val[2]);
        temp->next = NULL;
        Nowpoint->next = temp;
        Nowpoint = temp;    
    }
    printf("sort or not?(1:yes  0:no)\n");
    int tmp;
    scanf("%d",&tmp);
    if (tmp!=0)
    { 
    sortlist(data.head);
     printf("sort complete!\n");
    }
    fclose(fp);
}