请直接运行Lab6.exe
