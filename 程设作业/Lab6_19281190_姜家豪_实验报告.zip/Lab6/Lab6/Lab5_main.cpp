# include "Lab5_conf.h"
# include "Lab5_loadfile.h"
# include "Lab5_call.h"
# include "Lab5_data.h"
# include "Lab5_view.h"
# include <cstdio>
# include <cstring>
# include <iostream>

extern struct Lab5init Lab;

void run(int argc,char* argv[])
{
    self_check();//自我检查函数
    init();//初始化工作模式
    out_menu();//打印菜单
    while(1)
    {
        printf("请输入您要执行的程序序号(输入16再次展示菜单)：\n");
        int num;
        scanf("%d",&num);
        if (num==0) break;

        if (num==16)
        {
            out_menu();
            continue;
        }

        if (num==15)
        {
            change_conf();//调用子菜单
            continue;
        }

        switch (num)
        {
            case 1:
            case 7:
            case 8:
            case 9:
            case 10:
                creat_file('t');//创建文本数据记录文件
                break;
            case 2:
            case 11:
            case 12:
            case 13:
            case 14:
                creat_file('d');//创建二进制数据记录文件
                break;
        }
        get_datapath();//获取默认文件储存地址
        switch(num)
        {   
            case 3:
            case 7:
            case 11:
                if (Lab.mod[0]!='a')
                {
                    find_path();//交互模式下寻找输入指定打开路径
                }
                read_array();//读取进二维数组
                out_array();//打印二维数组
                break;
            case 4:
            case 8:
            case 12:
                if (Lab.mod[0]!='a')
                {
                    find_path();
                }
                read_struct1();//读取进结构体
                out_struct1();//打印结构体
                break;
            case 5:
            case 9:
            case 13:
                if (Lab.mod[0]!='a')
                {
                    find_path();
                }
                read_struct2();//读取进指针数组
                out_struct2();//打印指针数组
                break;
            case 6:
            case 10:
            case 14:
                if (Lab.mod[0]!='a')
                {
                    find_path();
                }
                read_list();//读取进链表
                out_list();//打印链表
                break;
        }
    }
    printf("problem 5 end\n");
    return;
}