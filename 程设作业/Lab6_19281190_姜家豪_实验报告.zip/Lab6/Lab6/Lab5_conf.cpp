# include <iostream>
# include <cstdio>
# include <io.h>
# include "Lab5_data.h"

extern struct Lab5init Lab;

void ext(const char* a)
{
    if (access(a,0)==0)
    {
        printf("%s is prepared\n",a);
    }
    else{
        printf("Can't find %s\n",a);
        exit(0);
    }
}

void self_check()
{
    ext("Lab4.exe");
    ext("conf.ini");
    ext("conf_Lab5.ini");
    printf("program is prepared!\n");
}

void out_menu()
{
    printf("姜家豪 的实验 5 程序：\n");
    printf("\t1. 调用实验 4 程序生成记录文件（文本方式）\n");
    printf("\t2. 调用实验 4 程序生成记录文件（二进制方式）\n");
    printf("\t3. 读取指定数据记录文件并排序（二维数组存储方式）\n");
    printf("\t4. 读取指定数据记录文件并排序（结构体数组存储方式\n\t5. 读取指定数据记录文件并排序（指针数组存储方式）\n\t6. 读取指定数据记录文件并排序（链表存储方式）\n\t7. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（文本方式输出，二维数组方式存储）\n\t8. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（文本方式输出，结构体数组方式存储）\n\t9. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（文本方式输出，指针数组方式存储）\n\t10. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（文本方式输出，链表方式存储）\n\t11. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（二进制方式输出，二维数组方式存储）\n\t12. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（二进制方式输出，结构体数组方式存储）\n\t13. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（二进制方式输出，指针数组方式存储）\n\t14. 调用实验 4 生成数据记录文件，同时读取数据记录文件并排序（二进制方式输出，链表方式存储）\n\t15. 重新设置配置参数值\n\t0. 退出\n");
}

void init()
{
    FILE* fp;
    fp = fopen("conf_Lab5.ini","r");
    fscanf(fp,"%s",Lab.mod);
}

void out_demenu(void)
{
    printf("\t1.改变工作运行模式\n\t2.改变储存路径\n\t3.改变文件名\n\t4.改变第一第二个数据的最小值\n\t5.改变第一第二个数据的最大值\n\t6.改变第三个数据的最小值\n\t7.改变第三个数据的最大值\n\t8.改变数据条数最小值\n\t9.改变数据条数最大值\n\t0.返回上一级菜单\n");
}

void change_conf(void)
{
    out_demenu();//打印子菜单

    while(1)
    {

        FILE* fp;
    struct Lab4init LLab;
    if((fp = fopen("conf.ini","r"))==NULL)
    {
        printf("open conf file fail!\n");
        exit(0);
    }
    fscanf(fp,"%s",LLab.filepath);
    fscanf(fp,"%s",LLab.filename);
    fscanf(fp,"%d",&LLab.maxvalue12);
    fscanf(fp,"%d",&LLab.minvalue12);
    fscanf(fp,"%d",&LLab.maxvalue3);
    fscanf(fp,"%d",&LLab.minvalue3);
    fscanf(fp,"%d",&LLab.maxrecord);
    fscanf(fp,"%d",&LLab.minrecord);
    fclose(fp);
    if((fp = fopen("conf.ini","w"))==NULL)
    {
        printf("open conf file fail!\n");
        exit(0);
    }

    printf("请输入你需要的程序编号(输入10再次展示菜单)：\n");
    int num1,num;

    fflush(stdin);
    scanf("%d",&num1);
    fflush(stdin);
    switch(num1)
    {
        case 1:
            printf("will change the mod?1(yes):0(no)\n");
            scanf("%d",&num);
            if (num!=0)
            {   
            if(Lab.mod[0]=='a'){
            strcpy(Lab.mod,"mutuality");
            }else{
            strcpy(Lab.mod,"auto");
            }
            printf("now mod is :%s\n",Lab.mod);
        
            FILE* fp2;
            if((fp2 = fopen("conf_Lab5.ini","w"))==NULL)
            {
                printf("open conf file fail!\n");
                exit(0);
            }
            fprintf(fp2,"%s\n",Lab.mod);
            fclose(fp2);
        }
        break;
  
    case 2:
    printf("change the filepath?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%s",LLab.filepath);
    }
    break;

    case 3:
    printf("change the filename?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%s",LLab.filename);
    }
    break;


    case 5:
    printf("change the maxvalue(12)?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%d",&LLab.maxvalue12);
    }
    break;

    case 4:
    printf("change the minvalue(12)?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%d",&LLab.minvalue12);
    }
    break;


    case 7:
    printf("change the maxvalue3?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%d",&LLab.maxvalue3);
    }
    break;

    case 6:
    printf("change the minvalue3?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%d",&LLab.minvalue3);
    }
    break;

    case 8:
    printf("change the minrecord?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%d",&LLab.minrecord);
    }
    break;

    case 9:
    printf("change the maxrecord?1(yes):0(no)\n");
    scanf("%d",&num);
    if (num!=0)
    {
        printf("please input:\n");
        scanf("%d",&LLab.maxrecord);
    }
    break;
    }

    fprintf(fp,"%s\n",LLab.filepath);
    fprintf(fp,"%s\n",LLab.filename);
    fprintf(fp,"%d\n",LLab.maxvalue12);
    fprintf(fp,"%d\n",LLab.minvalue12);
    fprintf(fp,"%d\n",LLab.maxvalue3);
    fprintf(fp,"%d\n",LLab.minvalue3);
    fprintf(fp,"%d\n",LLab.maxrecord);
    fprintf(fp,"%d\n",LLab.minrecord);
    fclose(fp);
    if (num1==0) break;
    if (num1==10)
    {
        out_demenu();
        continue;
    }
    }
}