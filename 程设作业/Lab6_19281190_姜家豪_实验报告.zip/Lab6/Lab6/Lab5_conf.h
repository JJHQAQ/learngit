# ifndef JJH_conf
# define  JJH_conf 233

void self_check(void);
void out_menu(void);
void init(void);
void change_conf(void);
#endif