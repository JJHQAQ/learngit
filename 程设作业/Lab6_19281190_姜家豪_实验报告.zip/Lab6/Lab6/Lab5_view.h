#ifndef JJH_view
#define JJH_view 233

void out_array(void);
void out_struct1(void);
void out_struct2(void);
void out_list(void);
#endif